<?php

return [
    'name' => 'Essentials',
    'module_version' => '3.0',
    'chat_refresh_interval' => 20 //Interval to check for new chats in seconds, default 20sec
];
